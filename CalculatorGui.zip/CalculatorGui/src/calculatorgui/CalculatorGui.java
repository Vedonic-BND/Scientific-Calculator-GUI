package calculatorgui;

import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class CalculatorGui {
    public static void main(String[] args) {
        CalcFrame calc = new CalcFrame();
        calc.setVisible(true);
    }   
}


final class CalcFrame extends JFrame implements ActionListener{
    JPanel panel = new JPanel();
    JTextField txtScreen = new JTextField();
    
    //Number Buttons
    JButton btn[] = new JButton[11];
    String numbers[] = {"0","1","2","3","4","5","6","7","8","9", "."}; 
    
    //Operation Buttons
    JButton btnDiv = new JButton("÷");
    JButton btnMul = new JButton("x");
    JButton btnSub = new JButton("-");
    JButton btnAdd = new JButton("+");
    JButton btnEq = new JButton("=");
    JButton btnC = new JButton("C");
    JButton btnAns = new JButton("Answer");
    JButton btnDel = new JButton("<---");
    JButton btnSqr = new JButton("x²");
    JButton btnSqrt = new JButton("√");
    JButton btnF = new JButton("!");
    JButton btnAbs = new JButton("|x|");
    JButton btnExp = new JButton("^");
    
    CalcFrame(){
        //Frame Attributes
        super("Calculator");
        super.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        super.setSize(441, 524);
        super.setResizable(false);
        super.setLayout(null);
        super.setLocationRelativeTo(null);
        initComponents();
    }
    double op;
    double n1=0,n2=0;
    double ans;
    double history;
    public void initComponents(){
        //panel attributes
        panel.setLayout(new FlowLayout());

        //txtScreen attributes
        Color txtScreenColor = new Color(27,23,23);
        Font txtFont = new Font("Arial", Font.BOLD, 18);
        txtScreen.setSize(425, 155);
        txtScreen.setBackground(txtScreenColor);
        txtScreen.setForeground(Color.WHITE);
        txtScreen.setFont(txtFont);
        txtScreen.setLocation(0, 0);
        txtScreen.setBorder(null);
        txtScreen.setHorizontalAlignment(JTextField.SOUTH_EAST);
        txtScreen.setText("0");
        
        //Assigning number buttons
        for (int i = 0; i < btn.length; i++) {
            btn[i] = new JButton(numbers[i]); 
        }
        
        //number buttons
        Font BtnFont = new Font("Arial Black", Font.BOLD, 13);
        Color numberBtnColor = new Color(40,40,41);
        //btn0
        btn[0].setLocation(0, 419);
        btn[0].setSize(170, 66);
        btn[0].setBorder(null);
        btn[0].setBackground(numberBtnColor);
        btn[0].setForeground(Color.WHITE);
        btn[0].setFont(BtnFont);
        btn[0].addActionListener(this);
        //btn1
        btn[1].setLocation(0, 353);
        //btn2
        btn[2].setLocation(85, 353);
        //btn3
        btn[3].setLocation(170, 353);
        //btn4
        btn[4].setLocation(0, 287);
        //btn5
        btn[5].setLocation(85, 287);
        //btn6
        btn[6].setLocation(170, 287);
        //btn7
        btn[7].setLocation(0, 221);
        //btn8
        btn[8].setLocation(85, 221);
        //btn9
        btn[9].setLocation(170, 221);
        //btn(.)
        btn[10].setLocation(170, 419);
        
        //operation buttons
        Color opBtnFontColor = new Color(51,102,255);
        //btnDiv
        btnDiv.setLocation(255, 155);
        btnDiv.setSize(85, 66);
        btnDiv.setBorder(null);
        btnDiv.setBackground(numberBtnColor);
        btnDiv.setForeground(opBtnFontColor);
        btnDiv.setFont(BtnFont);
        btnDiv.addActionListener(this);
        //btnMul
        btnMul.setLocation(255, 221);
        btnMul.setSize(85, 66);
        btnMul.setBorder(null);
        btnMul.setBackground(numberBtnColor);
        btnMul.setForeground(opBtnFontColor);
        btnMul.setFont(BtnFont);
        btnMul.addActionListener(this);
        //btnAdd
        btnAdd.setLocation(255, 353);
        btnAdd.setSize(85, 66);
        btnAdd.setBorder(null);
        btnAdd.setBackground(numberBtnColor);
        btnAdd.setForeground(opBtnFontColor);
        btnAdd.setFont(BtnFont);
        btnAdd.addActionListener(this);
        //btnSub
        btnSub.setLocation(255, 287);
        btnSub.setSize(85, 66);
        btnSub.setBorder(null);
        btnSub.setBackground(numberBtnColor);
        btnSub.setForeground(opBtnFontColor);
        btnSub.setFont(BtnFont);
        btnSub.addActionListener(this);
        //btnEq
        btnEq.setLocation(255, 419);
        btnEq.setSize(85, 66);
        btnEq.setBorder(null);
        Color eqColor = new Color(0,102,255);
        btnEq.setBackground(eqColor);
        btnEq.setForeground(Color.WHITE);
        btnEq.addActionListener(this);
        //btnC
        btnC.setLocation(0, 155);
        btnC.setSize(85, 66);
        btnC.setBorder(null);
        btnC.setBackground(numberBtnColor);
        btnC.setForeground(opBtnFontColor);
        btnC.setFont(BtnFont);
        btnC.addActionListener(this);
        //btnAns
        btnAns.setLocation(85, 155);
        btnAns.setSize(85, 66);
        btnAns.setBorder(null);
        btnAns.setBackground(numberBtnColor);
        btnAns.setForeground(opBtnFontColor);
        btnAns.setFont(BtnFont);
        btnAns.addActionListener(this);
        //btnDel
        btnDel.setLocation(170, 155);
        btnDel.setSize(85, 66);
        btnDel.setBorder(null);
        btnDel.setBackground(numberBtnColor);
        btnDel.setForeground(opBtnFontColor);
        btnDel.setFont(BtnFont);
        btnDel.addActionListener(this);
        //lastcolumnbutton
        Color lastColBtn = new Color(0,51,204);
        //btnSqr
        btnSqr.setLocation(340, 155);
        btnSqr.setSize(85, 66);
        btnSqr.setBorder(null);
        btnSqr.setBackground(lastColBtn);
        btnSqr.setForeground(Color.WHITE);
        btnSqr.addActionListener(this);
        //btnSqrt
        btnSqrt.setLocation(340, 221);
        btnSqrt.setSize(85, 66);
        btnSqrt.setBorder(null);
        btnSqrt.setBackground(lastColBtn);
        btnSqrt.setForeground(Color.WHITE);
        btnSqrt.addActionListener(this);
        //btnF
        btnF.setLocation(340, 287); 
        btnF.setSize(85, 66);
        btnF.setBorder(null);
        btnF.setBackground(lastColBtn);
        btnF.setForeground(Color.WHITE);
        btnF.addActionListener(this);
        //btnAbs
        btnAbs.setLocation(340, 353);
        btnAbs.setSize(85, 66);
        btnAbs.setBorder(null);
        btnAbs.setBackground(lastColBtn);
        btnAbs.setForeground(Color.WHITE);
        btnAbs.addActionListener(this);
        //btnExp
        btnExp.setLocation(340, 419);
        btnExp.setSize(85, 66);
        btnExp.setBorder(null);
        btnExp.setBackground(lastColBtn);
        btnExp.setForeground(Color.WHITE);
        btnExp.addActionListener(this);
        
        //Add Objects To Screen
        super.add(txtScreen);
        super.add(btn[0]);
        super.add(btnDiv);
        super.add(btnMul);
        super.add(btnAdd);
        super.add(btnSub);
        super.add(btnEq);
        super.add(btnC);
        super.add(btnAns);
        super.add(btnDel);
        super.add(btnSqr);
        super.add(btnSqrt);
        super.add(btnF);
        super.add(btnAbs);
        super.add(btnExp);
        
        for (int i = 1; i < btn.length; i++) {
            btn[i].setSize(85,66);
            btn[i].setBorder(null);
            btn[i].setBackground(numberBtnColor);
            btn[i].setForeground(Color.WHITE);
            btn[i].setFont(BtnFont);
            btn[i].addActionListener(this);
            super.add(btn[i]);
        }
        
    }
    
    @Override
    public void actionPerformed(ActionEvent evt){
        //event for del button
        if (evt.getSource() == btnDel) {
            txtScreen.setText(txtScreen.getText().substring(0,txtScreen.getText().length()-1));
        }
        
        //event for number buttons
        if (evt.getSource() == btn[0]) {
            if (txtScreen.getText().equals("0")) {
               txtScreen.setText("0");
            }else{
                txtScreen.setText(txtScreen.getText() + "0");
            }
        }
        
        if (evt.getSource() == btn[1]) {
            if (txtScreen.getText().equals("0")) {
               txtScreen.setText("1");
            }else{
                txtScreen.setText(txtScreen.getText() + "1");
            }
        }
        
        if (evt.getSource() == btn[2]) {
            if (txtScreen.getText().equals("0")) {
               txtScreen.setText("2");
            }else{
                txtScreen.setText(txtScreen.getText() + "2");
            }
        }
        
        if (evt.getSource() == btn[3]) {
            if (txtScreen.getText().equals("0")) {
               txtScreen.setText("3");
            }else{
                txtScreen.setText(txtScreen.getText() + "3");
            }
        }
        
        if (evt.getSource() == btn[4]) {
            if (txtScreen.getText().equals("0")) {
               txtScreen.setText("4");
            }else{
                txtScreen.setText(txtScreen.getText() + "4");
            }
        }
        
        if (evt.getSource() == btn[5]) {
            if (txtScreen.getText().equals("0")) {
               txtScreen.setText("5");
            }else{
                txtScreen.setText(txtScreen.getText() + "5");
            }
        }
        
        if (evt.getSource() == btn[6]) {
            if (txtScreen.getText().equals("0")) {
               txtScreen.setText("6");
            }else{
                txtScreen.setText(txtScreen.getText() + "6");
            }
        }
        
        if (evt.getSource() == btn[7]) {
            if (txtScreen.getText().equals("0")) {
               txtScreen.setText("7");
            }else{
                txtScreen.setText(txtScreen.getText() + "7");
            }
        }
        
        if (evt.getSource() == btn[8]) {
            if (txtScreen.getText().equals("0")) {
               txtScreen.setText("8");
            }else{
                txtScreen.setText(txtScreen.getText() + "8");
            }
        }
        
        if (evt.getSource() == btn[9]) {
            if (txtScreen.getText().equals("0")) {
               txtScreen.setText("9");
            }else{
                txtScreen.setText(txtScreen.getText() + "9");
            }
        }
        
        //dot button
        if (evt.getSource() == btn[10]) {
            String text;
            text = txtScreen.getText();
            if (!text.contains(".")) {
                txtScreen.setText(txtScreen.getText()+".");
            } else {
                txtScreen.setText(txtScreen.getText()+"");
            }
              
        }
        
        //Clear button
        if (evt.getSource() == btnC) {
            txtScreen.setText("0");
            n1 = 0;
            n2 = 0;
            ans = 0;
            history = 0;
        }
        
        //History button
        if (evt.getSource() == btnAns) {
            txtScreen.setText(Double.toString(history));
            n1 = history;
            n2 = history;
        }
        
        //operation buttons
        if (evt.getSource() == btnDiv) {
            n1 = Double.parseDouble(txtScreen.getText());
            op = 1;
            txtScreen.setText("0");
        }
        if (evt.getSource() == btnMul) {
            n1 = Double.parseDouble(txtScreen.getText());
            op = 2;
            txtScreen.setText("0");
        }
        if (evt.getSource() == btnSub) {
            if (txtScreen.getText().equals("0") || txtScreen.getText().equals("0.0")) {
                txtScreen.setText("-");
            }else{
                n1 = Double.parseDouble(txtScreen.getText());
                op = 3;
                txtScreen.setText("0");
            }
        }
        if (evt.getSource() == btnAdd) {
            String text = txtScreen.getText();
            if (text.contains("-") && (!text.contains("0") && 
                                       !text.contains("1") &&
                                       !text.contains("2") &&
                                       !text.contains("3") &&
                                       !text.contains("4") &&
                                       !text.contains("5") &&
                                       !text.contains("6") &&
                                       !text.contains("7") &&
                                       !text.contains("8") &&
                                       !text.contains("9")) ) {
                
                String replaceAll = text.replaceAll("-", "0");
                txtScreen.setText(replaceAll);
            }else{
            n1 = Double.parseDouble(txtScreen.getText());
            op = 4;
            txtScreen.setText("0");
            }
        }
        
        //special operation btn
        if (evt.getSource() == btnSqr) {
            n1 = Double.parseDouble(txtScreen.getText());
            ans = Math.pow(n1, 2);
            txtScreen.setText(Double.toString(ans));
            history=ans;
            n1=0;
            n2=0;
        }
        if (evt.getSource() == btnSqrt) {
            n1 = Double.parseDouble(txtScreen.getText());
            ans = Math.sqrt(n1);
            txtScreen.setText(Double.toString(ans));
            history=ans;
            n1=0;
            n2=0;
        }
        if (evt.getSource() == btnF) {
            n1 = Double.parseDouble(txtScreen.getText());
            ans = factorial(n1);
            txtScreen.setText(Double.toString(ans));
            history=ans;
            n1=0;
            n2=0;
        }
        if (evt.getSource() == btnAbs) {
            n1 = Double.parseDouble(txtScreen.getText());
            ans = Math.abs(n1);
            txtScreen.setText(Double.toString(ans));
            history=ans;
            n1=0;
            n2=0;
        }
        if (evt.getSource() == btnExp) {
            n1 = Double.parseDouble(txtScreen.getText());
            op = 5;
            txtScreen.setText("0");
        }
        
        //if the equals btn is clicked
        if(evt.getSource() == btnEq) {
            n2 = Double.parseDouble(txtScreen.getText());
            
            switch((int)op){
                case 1:
                    ans = n1 / n2;
                    displayAns();
                    break;
                case 2:
                    ans = n1 * n2;
                    displayAns();
                    break;
                case 3:
                    ans = n1 - n2;
                    displayAns();
                    break;
                case 4:
                    ans = n1 + n2;
                    displayAns();
                    break;
                case 5:
                    ans = Math.pow(n1, n2);
                    displayAns();
                    break;
            }
        }
        
    }
    
    public void displayAns(){
        txtScreen.setText(Double.toString(ans));
        n1=0;
        n2=0;
        history=ans;
    }
    
    public double factorial(double n){
        String text = Double.toString(n);
        if (!text.contains(".")){
            if (n == 0) {
                return 1;
                }
        }else{
            txtScreen.setText("Syntax Error");
        }
        return n*factorial(n-1);   
    }
}